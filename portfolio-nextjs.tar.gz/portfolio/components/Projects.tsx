"use client";
import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { ExternalLink, GitBranch, ArrowUpRight } from "lucide-react";

const projects = [
  {
    id: "01",
    name: "NexusDB",
    tagline: "Distributed database engine",
    desc: "A horizontally scalable distributed SQL database built in Go. Handles 2M+ writes/sec with RAFT consensus and automatic sharding. Powers production workloads at 3 startups.",
    tags: ["Go", "RAFT", "gRPC", "PostgreSQL", "Docker"],
    color: "#7c3aed",
    featured: true,
    metrics: ["2M+ writes/sec", "99.99% uptime", "Sub-2ms latency"],
  },
  {
    id: "02",
    name: "FlowState",
    tagline: "Real-time collaboration platform",
    desc: "Notion-meets-Figma real-time editor with CRDT-based conflict resolution. Built with Next.js, YJS, and WebSocket clustering. 40k+ active users.",
    tags: ["TypeScript", "Next.js", "YJS", "WebSocket", "Redis"],
    color: "#06b6d4",
    featured: true,
    metrics: ["40k+ users", "< 50ms sync", "CRDT-based"],
  },
  {
    id: "03",
    name: "Sentinel",
    tagline: "AI-powered infrastructure monitor",
    desc: "ML-based anomaly detection for cloud infrastructure. Predicts outages 15 minutes before they happen using transformer models trained on system telemetry.",
    tags: ["Python", "PyTorch", "Kubernetes", "Prometheus", "FastAPI"],
    color: "#f59e0b",
    featured: true,
    metrics: ["15min early warning", "94% accuracy", "Cloud-agnostic"],
  },
  {
    id: "04",
    name: "Archipelago",
    tagline: "OSS microservices framework",
    desc: "Lightweight service mesh with built-in observability, rate limiting, and circuit breaking for Node.js microservices.",
    tags: ["Node.js", "TypeScript", "OpenTelemetry"],
    color: "#10b981",
    featured: false,
    metrics: ["2k+ GitHub stars", "npm weekly 50k+"],
  },
  {
    id: "05",
    name: "Prism CLI",
    tagline: "Developer productivity toolchain",
    desc: "An opinionated CLI for spinning up full-stack projects with one command. Supports 12 frameworks and auto-configures CI/CD.",
    tags: ["Rust", "CLI", "GitHub Actions"],
    color: "#ec4899",
    featured: false,
    metrics: ["5k+ installs/week", "12 frameworks"],
  },
  {
    id: "06",
    name: "Clearwater",
    tagline: "Financial data aggregation API",
    desc: "REST & GraphQL API aggregating financial data from 30+ sources with normalization, caching, and webhook subscriptions.",
    tags: ["Node.js", "GraphQL", "PostgreSQL", "Redis"],
    color: "#8b5cf6",
    featured: false,
    metrics: ["30+ data sources", "10M+ API calls/day"],
  },
];

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [hovered, setHovered] = useState(false);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  if (project.featured) {
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 40 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: index * 0.1 }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="relative col-span-1 lg:col-span-2 p-8 overflow-hidden"
        style={{
          border: `1px solid ${hovered ? project.color + "60" : "var(--border)"}`,
          background: hovered ? "var(--surface)" : "var(--surface)",
          transition: "all 0.4s ease",
          boxShadow: hovered ? `0 0 40px ${project.color}20` : "none",
        }}
      >
        <div
          className="absolute inset-0 opacity-0 transition-opacity duration-500 pointer-events-none"
          style={{
            background: `radial-gradient(ellipse at top left, ${project.color}08 0%, transparent 60%)`,
            opacity: hovered ? 1 : 0,
          }}
        />

        <div className="relative z-10 grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-3">
              <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.7rem", color: project.color }}>
                {project.id}
              </span>
              <div className="h-px flex-1 max-w-8" style={{ background: project.color + "40" }} />
              <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.65rem", color: "var(--muted)" }}>
                Featured Project
              </span>
            </div>

            <h3
              style={{
                fontFamily: "Syne, sans-serif",
                fontSize: "1.8rem",
                fontWeight: 800,
                color: "var(--text)",
                letterSpacing: "-0.02em",
              }}
            >
              {project.name}
            </h3>
            <p style={{ fontFamily: "Space Mono, monospace", fontSize: "0.75rem", color: project.color, marginTop: "4px" }}>
              {project.tagline}
            </p>

            <p
              className="mt-4 text-sm leading-relaxed"
              style={{ fontFamily: "Space Mono, monospace", color: "var(--muted)", lineHeight: 1.8 }}
            >
              {project.desc}
            </p>

            <div className="flex flex-wrap gap-2 mt-4">
              {project.tags.map((tag) => (
                <span key={tag} className="tech-tag">{tag}</span>
              ))}
            </div>
          </div>

          <div className="flex flex-col justify-between">
            <div className="space-y-3">
              {project.metrics.map((m) => (
                <div
                  key={m}
                  className="px-4 py-2 text-xs"
                  style={{
                    border: `1px solid ${project.color}30`,
                    background: `${project.color}08`,
                    fontFamily: "Space Mono, monospace",
                    color: project.color,
                  }}
                >
                  ✦ {m}
                </div>
              ))}
            </div>

            <div className="flex gap-3 mt-4">
              <a
                href="#"
                className="flex items-center gap-2 px-4 py-2 text-xs transition-all duration-300"
                style={{
                  border: `1px solid ${project.color}`,
                  color: project.color,
                  fontFamily: "Space Mono, monospace",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.background = project.color;
                  (e.currentTarget as HTMLElement).style.color = "white";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "transparent";
                  (e.currentTarget as HTMLElement).style.color = project.color;
                }}
              >
                <GitBranch size={14} /> Code
              </a>
              <a
                href="#"
                className="flex items-center gap-2 px-4 py-2 text-xs transition-all duration-300"
                style={{
                  border: "1px solid var(--border)",
                  color: "var(--muted)",
                  fontFamily: "Space Mono, monospace",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--text)";
                  (e.currentTarget as HTMLElement).style.color = "var(--text)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                  (e.currentTarget as HTMLElement).style.color = "var(--muted)";
                }}
              >
                <ExternalLink size={14} /> Live
              </a>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="group relative p-6 overflow-hidden"
      style={{
        border: `1px solid ${hovered ? project.color + "50" : "var(--border)"}`,
        background: "var(--surface)",
        transition: "all 0.3s ease",
        transform: hovered ? "translateY(-4px)" : "none",
        boxShadow: hovered ? `0 20px 40px ${project.color}15` : "none",
      }}
    >
      <div className="flex items-start justify-between mb-4">
        <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.7rem", color: project.color }}>{project.id}</span>
        <div className="flex gap-3">
          <GitBranch size={16} style={{ color: "var(--muted)", cursor: "pointer", transition: "color 0.2s" }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text)")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted)")}
          />
          <ArrowUpRight size={16} style={{ color: "var(--muted)", cursor: "pointer", transition: "color 0.2s" }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text)")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted)")}
          />
        </div>
      </div>

      <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1.2rem", fontWeight: 700, color: "var(--text)" }}>
        {project.name}
      </h3>
      <p style={{ fontFamily: "Space Mono, monospace", fontSize: "0.7rem", color: project.color, marginTop: "2px" }}>
        {project.tagline}
      </p>
      <p className="mt-3 text-xs leading-relaxed" style={{ fontFamily: "Space Mono, monospace", color: "var(--muted)", lineHeight: 1.7 }}>
        {project.desc}
      </p>

      <div className="flex flex-wrap gap-2 mt-4">
        {project.tags.map((tag) => (
          <span key={tag} className="tech-tag" style={{ fontSize: "0.6rem" }}>{tag}</span>
        ))}
      </div>
    </motion.div>
  );
}

export default function Projects() {
  const headerRef = useRef(null);
  const isInView = useInView(headerRef, { once: true });

  return (
    <section id="projects" className="py-32 px-6 relative">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse at 20% 50%, rgba(124,58,237,0.04) 0%, transparent 50%)" }}
      />
      <div className="max-w-6xl mx-auto">
        <div ref={headerRef} className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="flex items-center gap-4 mb-4"
          >
            <span className="section-label">02. Projects</span>
            <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: "Syne, sans-serif",
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              fontWeight: 800,
              letterSpacing: "-0.02em",
            }}
          >
            Things I&apos;ve <span style={{ color: "var(--accent)" }}>Built</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {projects.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
