"use client";
import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const skillGroups = [
  {
    label: "Languages",
    color: "#7c3aed",
    skills: [
      { name: "TypeScript", level: 95 },
      { name: "Go", level: 88 },
      { name: "Python", level: 82 },
      { name: "Rust", level: 65 },
    ],
  },
  {
    label: "Frontend",
    color: "#06b6d4",
    skills: [
      { name: "React / Next.js", level: 96 },
      { name: "WebGL / Three.js", level: 70 },
      { name: "CSS / Animations", level: 90 },
      { name: "Testing (Vitest)", level: 85 },
    ],
  },
  {
    label: "Backend & Infra",
    color: "#f59e0b",
    skills: [
      { name: "Node.js", level: 94 },
      { name: "PostgreSQL", level: 92 },
      { name: "Kubernetes", level: 78 },
      { name: "Redis", level: 88 },
    ],
  },
  {
    label: "Systems",
    color: "#10b981",
    skills: [
      { name: "System Design", level: 90 },
      { name: "Distributed Systems", level: 82 },
      { name: "Performance Tuning", level: 85 },
      { name: "Security", level: 76 },
    ],
  },
];

const tools = [
  "VS Code", "Neovim", "Docker", "Terraform", "GitHub Actions",
  "DataDog", "Figma", "Linear", "Notion", "Obsidian",
  "Postman", "k9s", "pgAdmin", "Grafana", "Sentry",
];

function SkillBar({ name, level, color, delay }: { name: string; level: number; color: string; delay: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <div ref={ref} className="mb-4">
      <div className="flex justify-between items-center mb-1">
        <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.75rem", color: "var(--text)" }}>{name}</span>
        <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.65rem", color: color }}>{level}%</span>
      </div>
      <div
        className="relative h-px w-full"
        style={{ background: "var(--border)" }}
      >
        <motion.div
          initial={{ width: 0 }}
          animate={isInView ? { width: `${level}%` } : {}}
          transition={{ duration: 1, delay, ease: "easeOut" }}
          className="absolute left-0 top-0 h-full"
          style={{ background: color }}
        />
        <motion.div
          initial={{ left: "0%" }}
          animate={isInView ? { left: `${level}%` } : {}}
          transition={{ duration: 1, delay, ease: "easeOut" }}
          className="absolute top-1/2 -translate-y-1/2 w-2 h-2 rounded-full"
          style={{
            background: color,
            boxShadow: `0 0 8px ${color}`,
            transform: "translateX(-50%) translateY(-50%)",
          }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section id="skills" className="py-32 px-6 relative" style={{ background: "var(--surface)" }}>
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="flex items-center gap-4 mb-4"
          >
            <span className="section-label">03. Skills</span>
            <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: "Syne, sans-serif",
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              fontWeight: 800,
              letterSpacing: "-0.02em",
            }}
          >
            My <span style={{ color: "var(--accent)" }}>Toolkit</span>
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {skillGroups.map((group, gi) => (
            <motion.div
              key={group.label}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: gi * 0.1 + 0.2 }}
            >
              <div className="flex items-center gap-2 mb-6">
                <div className="w-2 h-2 rounded-full" style={{ background: group.color }} />
                <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.7rem", color: group.color, letterSpacing: "0.2em", textTransform: "uppercase" }}>
                  {group.label}
                </span>
              </div>
              {group.skills.map((skill, si) => (
                <SkillBar
                  key={skill.name}
                  name={skill.name}
                  level={skill.level}
                  color={group.color}
                  delay={gi * 0.1 + si * 0.1 + 0.3}
                />
              ))}
            </motion.div>
          ))}
        </div>

        {/* Tools Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="p-8"
          style={{ border: "1px solid var(--border)", background: "var(--bg)" }}
        >
          <div className="flex items-center gap-3 mb-6">
            <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.7rem", color: "var(--accent)", letterSpacing: "0.2em", textTransform: "uppercase" }}>
              Daily Tools
            </span>
          </div>
          <div className="flex flex-wrap gap-3">
            {tools.map((tool, i) => (
              <motion.span
                key={tool}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.7 + i * 0.04 }}
                className="px-4 py-2 text-xs transition-all duration-300 cursor-default"
                style={{
                  border: "1px solid var(--border)",
                  fontFamily: "Space Mono, monospace",
                  color: "var(--muted)",
                  background: "var(--surface2)",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)";
                  (e.currentTarget as HTMLElement).style.color = "var(--accent)";
                  (e.currentTarget as HTMLElement).style.background = "rgba(124,58,237,0.08)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                  (e.currentTarget as HTMLElement).style.color = "var(--muted)";
                  (e.currentTarget as HTMLElement).style.background = "var(--surface2)";
                }}
              >
                {tool}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
