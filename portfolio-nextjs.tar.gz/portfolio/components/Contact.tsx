"use client";
import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Mail, MapPin, GitBranch, Globe, X, Send } from "lucide-react";

export default function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async () => {
    setSending(true);
    await new Promise(r => setTimeout(r, 1500));
    setSending(false);
    setSent(true);
  };

  return (
    <section id="contact" className="py-32 px-6 relative" style={{ background: "var(--surface)" }}>
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse at 50% 100%, rgba(124,58,237,0.08) 0%, transparent 60%)" }}
      />

      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="flex items-center gap-4 mb-4"
          >
            <span className="section-label">05. Contact</span>
            <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: "Syne, sans-serif",
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              fontWeight: 800,
              letterSpacing: "-0.02em",
            }}
          >
            Let&apos;s <span style={{ color: "var(--accent)" }}>Build Together</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 0.2 }}
            className="mt-4 max-w-xl text-sm"
            style={{ fontFamily: "Space Mono, monospace", color: "var(--muted)", lineHeight: 1.8 }}
          >
            I&apos;m currently open to new opportunities, interesting projects, and collaborations. 
            Whether you have a question, a project idea, or just want to chat tech — my inbox is open.
          </motion.p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left: Form */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
          >
            {sent ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-8 text-center"
                style={{ border: "1px solid #10b981", background: "rgba(16,185,129,0.05)" }}
              >
                <div style={{ fontSize: "3rem" }}>✓</div>
                <h3 style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, color: "#10b981", marginTop: "12px" }}>
                  Message Sent!
                </h3>
                <p style={{ fontFamily: "Space Mono, monospace", fontSize: "0.8rem", color: "var(--muted)", marginTop: "8px" }}>
                  I&apos;ll get back to you within 24 hours.
                </p>
              </motion.div>
            ) : (
              <div className="space-y-4">
                {[
                  { key: "name", label: "Name", type: "text", placeholder: "Your name" },
                  { key: "email", label: "Email", type: "email", placeholder: "your@email.com" },
                ].map(({ key, label, type, placeholder }) => (
                  <div key={key}>
                    <label
                      className="block mb-2 text-xs"
                      style={{ fontFamily: "Space Mono, monospace", color: "var(--muted)", letterSpacing: "0.1em", textTransform: "uppercase" }}
                    >
                      {label}
                    </label>
                    <input
                      type={type}
                      placeholder={placeholder}
                      value={formData[key as keyof typeof formData]}
                      onChange={(e) => setFormData({ ...formData, [key]: e.target.value })}
                      className="w-full px-4 py-3 text-sm outline-none transition-all duration-300"
                      style={{
                        background: "var(--bg)",
                        border: "1px solid var(--border)",
                        color: "var(--text)",
                        fontFamily: "Space Mono, monospace",
                      }}
                      onFocus={(e) => (e.currentTarget.style.borderColor = "var(--accent)")}
                      onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
                    />
                  </div>
                ))}

                <div>
                  <label
                    className="block mb-2 text-xs"
                    style={{ fontFamily: "Space Mono, monospace", color: "var(--muted)", letterSpacing: "0.1em", textTransform: "uppercase" }}
                  >
                    Message
                  </label>
                  <textarea
                    rows={5}
                    placeholder="Tell me about your project..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 text-sm outline-none transition-all duration-300 resize-none"
                    style={{
                      background: "var(--bg)",
                      border: "1px solid var(--border)",
                      color: "var(--text)",
                      fontFamily: "Space Mono, monospace",
                    }}
                    onFocus={(e) => (e.currentTarget.style.borderColor = "var(--accent)")}
                    onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
                  />
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={sending}
                  className="w-full flex items-center justify-center gap-3 py-4 text-sm transition-all duration-300"
                  style={{
                    background: sending ? "var(--surface2)" : "var(--accent)",
                    color: "white",
                    fontFamily: "Space Mono, monospace",
                    letterSpacing: "0.1em",
                    border: "none",
                    cursor: sending ? "default" : "pointer",
                  }}
                >
                  {sending ? (
                    <span style={{ animation: "blink 1s step-end infinite" }}>Sending...</span>
                  ) : (
                    <>
                      <Send size={16} />
                      Send Message
                    </>
                  )}
                </button>
              </div>
            )}
          </motion.div>

          {/* Right: Contact info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4 }}
            className="space-y-6"
          >
            {[
              { icon: Mail, label: "Email", value: "alex@example.com", color: "#7c3aed" },
              { icon: MapPin, label: "Location", value: "San Francisco, CA", color: "#06b6d4" },
            ].map(({ icon: Icon, label, value, color }) => (
              <div key={label} className="flex gap-4 p-5" style={{ border: "1px solid var(--border)", background: "var(--bg)" }}>
                <div
                  className="flex-shrink-0 w-10 h-10 flex items-center justify-center"
                  style={{ background: `${color}15`, border: `1px solid ${color}30` }}
                >
                  <Icon size={18} style={{ color }} />
                </div>
                <div>
                  <div style={{ fontFamily: "Space Mono, monospace", fontSize: "0.65rem", color: "var(--muted)", letterSpacing: "0.2em", textTransform: "uppercase" }}>
                    {label}
                  </div>
                  <div style={{ fontFamily: "Space Mono, monospace", fontSize: "0.85rem", color: "var(--text)", marginTop: "4px" }}>
                    {value}
                  </div>
                </div>
              </div>
            ))}

            {/* Social links */}
            <div className="p-5" style={{ border: "1px solid var(--border)", background: "var(--bg)" }}>
              <div
                className="mb-4"
                style={{ fontFamily: "Space Mono, monospace", fontSize: "0.65rem", color: "var(--muted)", letterSpacing: "0.2em", textTransform: "uppercase" }}
              >
                Find me online
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: GitBranch, label: "GitHub", url: "#", color: "#e2e8f0" },
                  { icon: Globe, label: "LinkedIn", url: "#", color: "#0ea5e9" },
                  { icon: X, label: "Twitter", url: "#", color: "#1d9bf0" },
                ].map(({ icon: Icon, label, color }) => (
                  <a
                    key={label}
                    href="#"
                    className="flex flex-col items-center gap-2 p-3 text-center transition-all duration-300"
                    style={{ border: "1px solid var(--border)", background: "var(--surface)" }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.borderColor = color;
                      (e.currentTarget as HTMLElement).style.background = `${color}10`;
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                      (e.currentTarget as HTMLElement).style.background = "var(--surface)";
                    }}
                  >
                    <Icon size={18} style={{ color }} />
                    <span style={{ fontFamily: "Space Mono, monospace", fontSize: "0.6rem", color: "var(--muted)" }}>{label}</span>
                  </a>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
