"use client";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowDown, GitBranch, Globe, X, Mail } from "lucide-react";

const ROLES = ["Full Stack Engineer", "System Designer", "Open Source Contributor", "Performance Optimizer"];

export default function Hero() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [typing, setTyping] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Typewriter
  useEffect(() => {
    const role = ROLES[roleIndex];
    let i = typing ? displayed.length : displayed.length;
    
    if (typing) {
      if (displayed.length < role.length) {
        const t = setTimeout(() => setDisplayed(role.slice(0, displayed.length + 1)), 80);
        return () => clearTimeout(t);
      } else {
        const t = setTimeout(() => setTyping(false), 2000);
        return () => clearTimeout(t);
      }
    } else {
      if (displayed.length > 0) {
        const t = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 40);
        return () => clearTimeout(t);
      } else {
        setRoleIndex((prev) => (prev + 1) % ROLES.length);
        setTyping(true);
      }
    }
  }, [displayed, typing, roleIndex]);

  // Particle canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: { x: number; y: number; vx: number; vy: number; size: number; alpha: number }[] = [];

    for (let i = 0; i < 60; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.4 + 0.1,
      });
    }

    let animId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(124, 58, 237, ${p.alpha})`;
        ctx.fill();
      });

      // Draw connections
      particles.forEach((a, i) => {
        particles.slice(i + 1).forEach((b) => {
          const dist = Math.hypot(a.x - b.x, a.y - b.y);
          if (dist < 100) {
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(124, 58, 237, ${0.1 * (1 - dist / 100)})`;
            ctx.stroke();
          }
        });
      });

      animId = requestAnimationFrame(animate);
    };
    animate();

    const onResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center grid-bg overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

      {/* Orbs */}
      <div
        className="absolute pointer-events-none"
        style={{
          width: 600,
          height: 600,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(124,58,237,0.12) 0%, transparent 70%)",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          filter: "blur(40px)",
        }}
      />
      <div
        className="absolute pointer-events-none"
        style={{
          width: 400,
          height: 400,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(6,182,212,0.08) 0%, transparent 70%)",
          top: "20%",
          right: "10%",
          filter: "blur(60px)",
          animation: "float 8s ease-in-out infinite",
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left content */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3 mb-6"
            >
              <div className="h-px w-12" style={{ background: "var(--accent)" }} />
              <span className="section-label">Available for work</span>
              <div
                className="w-2 h-2 rounded-full"
                style={{
                  background: "#10b981",
                  boxShadow: "0 0 8px #10b981",
                  animation: "pulseGlow 2s ease-in-out infinite",
                }}
              />
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              style={{
                fontFamily: "Syne, sans-serif",
                fontSize: "clamp(3rem, 8vw, 6rem)",
                fontWeight: 800,
                lineHeight: 0.95,
                letterSpacing: "-0.03em",
              }}
            >
              <span style={{ color: "var(--text)" }}>Alex</span>
              <br />
              <span className="glow-text" style={{ color: "var(--accent)" }}>
                Chen
              </span>
            </motion.h1>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-4 h-8 flex items-center"
            >
              <span
                style={{
                  fontFamily: "Space Mono, monospace",
                  fontSize: "1rem",
                  color: "var(--accent2)",
                }}
              >
                {displayed}
                <span className="blink" style={{ color: "var(--accent)" }}>_</span>
              </span>
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="mt-6 text-sm leading-relaxed max-w-md"
              style={{ color: "var(--muted)", fontFamily: "Space Mono, monospace", lineHeight: 1.8 }}
            >
              I architect and build scalable systems that handle millions of requests. 
              From elegant APIs to blazing-fast frontends — I obsess over every detail.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-8 flex flex-wrap gap-4"
            >
              <button
                onClick={() => document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })}
                className="gradient-border relative px-8 py-3 text-sm font-bold"
                style={{
                  background: "var(--bg)",
                  color: "var(--text)",
                  fontFamily: "Space Mono, monospace",
                  letterSpacing: "0.05em",
                  borderRadius: "2px",
                }}
              >
                View Projects
              </button>
              <button
                onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
                className="px-8 py-3 text-sm"
                style={{
                  border: "1px solid var(--border)",
                  color: "var(--muted)",
                  fontFamily: "Space Mono, monospace",
                  letterSpacing: "0.05em",
                  transition: "all 0.3s ease",
                  borderRadius: "2px",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)";
                  (e.currentTarget as HTMLElement).style.color = "var(--text)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                  (e.currentTarget as HTMLElement).style.color = "var(--muted)";
                }}
              >
                Get In Touch
              </button>
            </motion.div>

            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="mt-10 flex items-center gap-6"
            >
              {[
                { icon: GitBranch, href: "#", label: "GitHub" },
                { icon: Globe, href: "#", label: "LinkedIn" },
                { icon: X, href: "#", label: "Twitter" },
                { icon: Mail, href: "#", label: "Email" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  className="group flex items-center gap-2 text-xs"
                  style={{ color: "var(--muted)", fontFamily: "Space Mono, monospace", transition: "color 0.2s" }}
                  onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.color = "var(--accent)"}
                  onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.color = "var(--muted)"}
                >
                  <Icon size={16} />
                </a>
              ))}
              <div className="h-px flex-1 max-w-20" style={{ background: "var(--border)" }} />
            </motion.div>
          </div>

          {/* Right: Code terminal */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="hidden lg:block"
          >
            <div
              className="relative glow-border rounded-lg overflow-hidden"
              style={{ background: "var(--surface)" }}
            >
              {/* Terminal header */}
              <div
                className="flex items-center gap-2 px-4 py-3"
                style={{ borderBottom: "1px solid var(--border)", background: "var(--surface2)" }}
              >
                {["#ef4444", "#f59e0b", "#10b981"].map((c) => (
                  <div key={c} className="w-3 h-3 rounded-full" style={{ background: c }} />
                ))}
                <span
                  className="ml-2 text-xs"
                  style={{ color: "var(--muted)", fontFamily: "Space Mono, monospace" }}
                >
                  ~/alex-chen/portfolio.ts
                </span>
              </div>

              {/* Code content */}
              <div className="p-6 text-sm" style={{ fontFamily: "Space Mono, monospace", lineHeight: 1.9 }}>
                {[
                  { line: "const developer = {", color: "var(--text)" },
                  { line: '  name: "Alex Chen",', color: "var(--text)", indent: true },
                  { line: '  location: "San Francisco, CA",', indent: true, strColor: "#10b981" },
                  { line: '  experience: "6+ years",', indent: true, strColor: "#10b981" },
                  { line: "  stack: [", indent: true, color: "var(--text)" },
                  { line: '    "TypeScript", "React", "Node.js",', indent2: true, strColor: "#f59e0b" },
                  { line: '    "Go", "PostgreSQL", "K8s"', indent2: true, strColor: "#f59e0b" },
                  { line: "  ],", indent: true, color: "var(--text)" },
                  { line: "  passion: () => {", indent: true, color: "var(--accent2)" },
                  { line: '    return "Building things";', indent2: true, strColor: "#10b981" },
                  { line: "  }", indent: true, color: "var(--text)" },
                  { line: "};", color: "var(--text)" },
                ].map(({ line, color, strColor, indent, indent2 }, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + i * 0.07 }}
                    className="flex"
                  >
                    <span className="mr-4 w-5 text-right" style={{ color: "var(--border)", userSelect: "none" }}>
                      {i + 1}
                    </span>
                    <span style={{ paddingLeft: indent2 ? "2rem" : indent ? "1rem" : 0 }}>
                      {strColor ? (
                        <span style={{ color: strColor }}>{line}</span>
                      ) : (
                        <span style={{ color: color || "var(--text)" }}>{line}</span>
                      )}
                    </span>
                  </motion.div>
                ))}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 2 }}
                  className="flex mt-2"
                >
                  <span className="mr-4 w-5 text-right" style={{ color: "var(--border)" }}>13</span>
                  <span style={{ color: "var(--accent2)" }}>
                    {">"}{" "}
                    <span style={{ color: "var(--accent)" }}>
                      developer.passion()<span className="blink">█</span>
                    </span>
                  </span>
                </motion.div>
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-4 mt-4">
              {[
                { value: "50+", label: "Projects Shipped" },
                { value: "6+", label: "Years Experience" },
                { value: "12M+", label: "Requests/Day" },
              ].map(({ value, label }) => (
                <div
                  key={label}
                  className="p-4 text-center"
                  style={{ border: "1px solid var(--border)", background: "var(--surface)" }}
                >
                  <div
                    style={{ fontFamily: "Syne, sans-serif", fontSize: "1.5rem", fontWeight: 800, color: "var(--accent)" }}
                  >
                    {value}
                  </div>
                  <div style={{ fontFamily: "Space Mono, monospace", fontSize: "0.65rem", color: "var(--muted)", marginTop: "4px" }}>
                    {label}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="section-label text-xs">Scroll</span>
          <motion.div animate={{ y: [0, 8, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}>
            <ArrowDown size={16} style={{ color: "var(--accent)" }} />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
