"use client";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" ref={ref} className="py-32 px-6 relative">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 80% 50%, rgba(6,182,212,0.04) 0%, transparent 60%)",
        }}
      />
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-4 mb-4"
            >
              <span className="section-label">01. About</span>
              <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.1 }}
              style={{
                fontFamily: "Syne, sans-serif",
                fontSize: "clamp(2rem, 4vw, 3.5rem)",
                fontWeight: 800,
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
              }}
            >
              Crafting Software
              <br />
              <span style={{ color: "var(--accent)" }}>with Purpose</span>
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 }}
              className="mt-6 space-y-4"
              style={{ fontFamily: "Space Mono, monospace", fontSize: "0.85rem", color: "var(--muted)", lineHeight: 1.9 }}
            >
              <p>
                I&apos;m a software engineer with a deep love for building systems that scale. 
                I started coding at 14, shipped my first SaaS at 21, and never looked back.
              </p>
              <p>
                Currently focused on distributed systems, developer tooling, and the intersection 
                of great UX and high-performance backends. I believe software should be both 
                technically excellent <span style={{ color: "var(--accent2)" }}>and</span> a joy to use.
              </p>
              <p>
                When I&apos;m not in the terminal, I contribute to open source, mentor junior engineers, 
                and write about software architecture.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.4 }}
              className="mt-8 grid grid-cols-2 gap-3"
            >
              {[
                "TypeScript / Go",
                "React / Next.js",
                "PostgreSQL / Redis",
                "Docker / Kubernetes",
                "AWS / GCP",
                "System Design",
              ].map((skill, i) => (
                <div key={skill} className="flex items-center gap-2 text-xs" style={{ fontFamily: "Space Mono, monospace" }}>
                  <span style={{ color: "var(--accent)" }}>▸</span>
                  <span style={{ color: "var(--muted)" }}>{skill}</span>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right: Photo placeholder with decorative frame */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="relative flex justify-center"
          >
            <div className="relative">
              {/* Decorative offset border */}
              <div
                className="absolute"
                style={{
                  inset: 0,
                  border: "1px solid var(--accent)",
                  transform: "translate(12px, 12px)",
                  zIndex: 0,
                }}
              />
              {/* Main image box */}
              <div
                className="relative z-10 w-72 h-80 flex items-center justify-center"
                style={{
                  background: "var(--surface)",
                  border: "1px solid var(--border)",
                  overflow: "hidden",
                }}
              >
                {/* Decorative pattern instead of real photo */}
                <div className="w-full h-full relative" style={{ background: "var(--surface2)" }}>
                  {/* Geometric design */}
                  <svg width="100%" height="100%" viewBox="0 0 288 320" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                      <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{ stopColor: "#7c3aed", stopOpacity: 0.6 }} />
                        <stop offset="100%" style={{ stopColor: "#06b6d4", stopOpacity: 0.3 }} />
                      </linearGradient>
                    </defs>
                    <circle cx="144" cy="140" r="80" fill="url(#grad1)" opacity="0.4" />
                    <circle cx="144" cy="140" r="55" fill="none" stroke="#7c3aed" strokeWidth="1" opacity="0.5" />
                    <circle cx="144" cy="140" r="30" fill="#7c3aed" opacity="0.3" />
                    {/* Person silhouette */}
                    <circle cx="144" cy="110" r="28" fill="#7c3aed" opacity="0.8" />
                    <path d="M90 240 Q90 190 144 185 Q198 190 198 240 Z" fill="#7c3aed" opacity="0.8" />
                    {/* Decorative lines */}
                    {[0,1,2,3,4].map(i => (
                      <line key={i} x1="20" y1={290 - i*8} x2="268" y2={290 - i*8} stroke="#1e1e2e" strokeWidth="1" />
                    ))}
                  </svg>
                  <div
                    className="absolute bottom-0 left-0 right-0 p-4"
                    style={{ background: "linear-gradient(transparent, var(--surface2))" }}
                  >
                    <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, color: "var(--text)", fontSize: "1.1rem" }}>
                      Alex Chen
                    </div>
                    <div className="tech-tag mt-1 inline-block">Software Engineer</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
