"use client";
import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";

const jobs = [
  {
    company: "Stripe",
    role: "Senior Software Engineer",
    period: "2022 — Present",
    location: "San Francisco, CA",
    color: "#7c3aed",
    highlights: [
      "Architected a real-time fraud detection system processing 3M+ transactions/day with < 10ms latency",
      "Led migration of 40+ microservices from monolith, reducing deployment time by 70%",
      "Mentored 6 engineers and established the team's TypeScript coding standards",
      "Built internal developer tooling adopted by 200+ engineers across the company",
    ],
    tags: ["Go", "TypeScript", "Kubernetes", "PostgreSQL", "Kafka"],
  },
  {
    company: "Vercel",
    role: "Software Engineer",
    period: "2020 — 2022",
    location: "Remote",
    color: "#06b6d4",
    highlights: [
      "Contributed core features to Next.js App Router — now used by 1M+ developers",
      "Reduced cold start times by 40% through V8 isolate optimization",
      "Built the initial version of Edge Middleware with sub-1ms execution overhead",
      "Shipped 12 customer-facing features including image optimization pipeline",
    ],
    tags: ["TypeScript", "React", "Edge Computing", "Rust", "C++"],
  },
  {
    company: "Coinbase",
    role: "Software Engineer",
    period: "2019 — 2020",
    location: "San Francisco, CA",
    color: "#f59e0b",
    highlights: [
      "Built the high-frequency trading infrastructure for Coinbase Pro, handling $2B+ daily volume",
      "Implemented WebSocket-based real-time order book with 10k+ concurrent connections",
      "Designed fault-tolerant architecture for cryptocurrency withdrawal processing",
    ],
    tags: ["Go", "Python", "Redis", "gRPC", "AWS"],
  },
  {
    company: "Lyft",
    role: "Junior Software Engineer",
    period: "2018 — 2019",
    location: "San Francisco, CA",
    color: "#ec4899",
    highlights: [
      "Developed driver matching algorithm improvements that reduced wait times by 8%",
      "Built internal analytics dashboard used by 200+ operations team members",
      "Contributed to the React Native driver app serving 500k+ active drivers",
    ],
    tags: ["Python", "React Native", "PostgreSQL", "Docker"],
  },
];

export default function Experience() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [active, setActive] = useState(0);

  return (
    <section id="experience" className="py-32 px-6 relative">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse at 60% 50%, rgba(6,182,212,0.03) 0%, transparent 60%)" }}
      />
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="flex items-center gap-4 mb-4"
          >
            <span className="section-label">04. Experience</span>
            <div className="flex-1 h-px" style={{ background: "var(--border)" }} />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: "Syne, sans-serif",
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              fontWeight: 800,
              letterSpacing: "-0.02em",
            }}
          >
            Where I&apos;ve <span style={{ color: "var(--accent)" }}>Worked</span>
          </motion.h2>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="grid md:grid-cols-4 gap-0"
          style={{ border: "1px solid var(--border)" }}
        >
          {/* Tab list */}
          <div style={{ borderRight: "1px solid var(--border)" }}>
            {jobs.map((job, i) => (
              <button
                key={job.company}
                onClick={() => setActive(i)}
                className="w-full text-left px-6 py-4 relative"
                style={{
                  borderBottom: i < jobs.length - 1 ? "1px solid var(--border)" : "none",
                  background: active === i ? "var(--surface)" : "transparent",
                  transition: "background 0.2s",
                }}
              >
                {active === i && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute left-0 top-0 bottom-0 w-0.5"
                    style={{ background: job.color }}
                  />
                )}
                <div
                  style={{
                    fontFamily: "Syne, sans-serif",
                    fontWeight: 700,
                    fontSize: "0.9rem",
                    color: active === i ? "var(--text)" : "var(--muted)",
                    transition: "color 0.2s",
                  }}
                >
                  {job.company}
                </div>
                <div
                  style={{
                    fontFamily: "Space Mono, monospace",
                    fontSize: "0.65rem",
                    color: active === i ? job.color : "var(--muted)",
                    marginTop: "2px",
                    transition: "color 0.2s",
                  }}
                >
                  {job.period}
                </div>
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="md:col-span-3 p-8" style={{ background: "var(--surface)" }}>
            {jobs.map((job, i) => (
              i === active && (
                <motion.div
                  key={job.company}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-6">
                    <div>
                      <h3
                        style={{
                          fontFamily: "Syne, sans-serif",
                          fontSize: "1.4rem",
                          fontWeight: 800,
                          color: "var(--text)",
                        }}
                      >
                        {job.role}
                        <span style={{ color: job.color }}> @ {job.company}</span>
                      </h3>
                      <div
                        style={{
                          fontFamily: "Space Mono, monospace",
                          fontSize: "0.7rem",
                          color: "var(--muted)",
                          marginTop: "4px",
                        }}
                      >
                        {job.period} · {job.location}
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-6">
                    {job.highlights.map((h, hi) => (
                      <motion.li
                        key={hi}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: hi * 0.08 }}
                        className="flex gap-3 text-sm"
                        style={{ fontFamily: "Space Mono, monospace", lineHeight: 1.7 }}
                      >
                        <span style={{ color: job.color, flexShrink: 0, marginTop: "2px" }}>▸</span>
                        <span style={{ color: "var(--muted)" }}>{h}</span>
                      </motion.li>
                    ))}
                  </ul>

                  <div className="flex flex-wrap gap-2 pt-4" style={{ borderTop: "1px solid var(--border)" }}>
                    {job.tags.map((tag) => (
                      <span key={tag} className="tech-tag">{tag}</span>
                    ))}
                  </div>
                </motion.div>
              )
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
