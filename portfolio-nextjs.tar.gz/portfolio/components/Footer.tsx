"use client";

export default function Footer() {
  return (
    <footer
      className="py-8 px-6 text-center"
      style={{ borderTop: "1px solid var(--border)", background: "var(--bg)" }}
    >
      <p style={{ fontFamily: "Space Mono, monospace", fontSize: "0.7rem", color: "var(--muted)" }}>
        Designed & built by{" "}
        <span style={{ color: "var(--accent)" }}>Alex Chen</span>
        {" "}·{" "}
        <span style={{ color: "var(--border)" }}>Built with Next.js & Framer Motion</span>
      </p>
    </footer>
  );
}
