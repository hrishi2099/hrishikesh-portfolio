"use client";
import { useEffect, useState } from "react";

export default function CustomCursor() {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [follower, setFollower] = useState({ x: -100, y: -100 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    let followerX = -100, followerY = -100;
    let animId: number;

    const move = (e: MouseEvent) => {
      setPos({ x: e.clientX, y: e.clientY });
    };

    const animate = () => {
      followerX += (pos.x - followerX) * 0.12;
      followerY += (pos.y - followerY) * 0.12;
      setFollower({ x: followerX, y: followerY });
      animId = requestAnimationFrame(animate);
    };

    const handleOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      setIsHovering(
        target.matches('a, button, [role="button"], input, textarea, select, label, [data-hover]') ||
        !!target.closest('a, button, [role="button"]')
      );
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseover", handleOver);
    animId = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", handleOver);
      cancelAnimationFrame(animId);
    };
  }, [pos.x, pos.y]);

  return (
    <>
      <div
        className="cursor"
        style={{
          left: pos.x - 6,
          top: pos.y - 6,
          transform: isHovering ? "scale(2)" : "scale(1)",
        }}
      />
      <div
        className="cursor-follower"
        style={{
          left: follower.x - 18,
          top: follower.y - 18,
          transform: isHovering ? "scale(1.5)" : "scale(1)",
          opacity: isHovering ? 0.8 : 0.5,
        }}
      />
    </>
  );
}
